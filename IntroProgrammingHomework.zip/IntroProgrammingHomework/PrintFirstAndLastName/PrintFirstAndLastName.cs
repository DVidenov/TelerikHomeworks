﻿using System;
class PrintFirstAndLastName
{
    static void Main()
    {
        Console.WriteLine("Denislav");
        Console.WriteLine("Videnov");
    }
}
