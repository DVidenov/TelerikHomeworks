﻿using System;

class CurrentDateAndTime
{
    static void Main()
    {
        Console.WriteLine(System.DateTime.Now);
    }
}
