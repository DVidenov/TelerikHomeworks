﻿using System;

class PrintMyName
{
    static void Main()
    {
        Console.WriteLine("Denislav Videnov");
    }
}